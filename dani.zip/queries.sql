/* Ejer1
SELECT d.DepartmentID, d.Name FROM HumanResources.Department AS d

SELECT d.DepartmentID, d.Name, d.GroupName FROM HumanResources.Department AS d
*/

/* Ejer 2:  Compare y explique los planes de las siguientes consultas: 52, vs 4
SELECT sod.UnitPrice, AVG(sod.UnitPriceDiscount) FROM Sales.SalesOrderDetail AS sod
where sod.UnitPrice > 800
GROUP BY sod.UnitPrice

SELECT sod.UnitPrice, AVG(sod.UnitPriceDiscount) FROM Sales.SalesOrderDetail AS sod
GROUP BY sod.UnitPrice
HAVING AVG(sod.UnitPriceDiscount) > .2
*/

/* Ejer 3 Explique por qu´e se usan planes distintos en las dos consultas siguientes: 1vs1
SELECT p.Name FROM Production.Product AS p WHERE p.Color = 'Grey'

SELECT p.Name FROM Production.Product AS p WHERE p.ProductNumber = 'CH-0234'
*/

/* Ejer 4: Explique las siguientes consultas 1vs72 
SELECT p.Name, p.ProductNumber, th.ReferenceOrderID FROM Production.Product AS p
JOIN Production.TransactionHistory AS th
ON th.ProductID = p.ProductID
WHERE th.ReferenceOrderID = 2550;

SELECT p.Name, p.ProductNumber, th.ReferenceOrderID FROM Production.Product AS p
JOIN Production.TransactionHistory AS th
ON th.ProductID = p.ProductID
WHERE th.ReferenceOrderID = 5346; 
*/

/* Ejer 5: Explique por qu´e las siguientes consultas tienen planes diferentes 441vs441
SELECT th.ProductID, AVG(th.ActualCost) FROM Production.TransactionHistory AS th
GROUP BY th.ProductID

SELECT th.ProductID, COUNT(th.ActualCost) FROM Production.TransactionHistory AS th
GROUP BY th.ProductID
*/

/* Ejer 6: Compare las siguientes consultas  1vs2*/
SELECT p.LastName + ', ' + p.FirstName, pp.PhoneNumber FROM Person.Person AS p
JOIN Person.PersonPhone AS pp ON pp.BusinessEntityID = p.BusinessEntityID
JOIN Person.PhoneNumberType AS pnt ON pnt.PhoneNumberTypeID = pp.PhoneNumberTypeID
WHERE pnt.Name = 'Cell' AND p.LastName = 'Dempsey';

SELECT p.LastName + ', ' + p.FirstName, pp.PhoneNumber FROM Person.Person AS p
JOIN Person.PersonPhone AS pp ON pp.BusinessEntityID = p.BusinessEntityID
JOIN Person.PhoneNumberType AS pnt ON pnt.PhoneNumberTypeID = pp.PhoneNumberTypeID
AND p.LastName = 'Dempsey';
