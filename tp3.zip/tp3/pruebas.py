import numpy as np
print(np.random.randint(2, size=(16, 16)))